// server.js
const express = require('express');
const mongoose = require('mongoose');
const { Schema, model } = require('mongoose');
const cors = require('cors'); // Import cors middleware
const app = express();
const PORT = process.env.PORT || 3000;

// Use CORS middleware
app.use(cors());

// Connect to MongoDB
mongoose.connect('mongodb://localhost/url-shortener', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Define URL schema
const urlSchema = new Schema({
  longUrl: { type: String, required: true },
  shortCode: { type: String, required: true, unique: true }
});

// Create URL model
const URL = model('URL', urlSchema);

// Middleware
app.use(express.json());

// Routes
app.post('/shorten', async (req, res) => {
  const { longUrl } = req.body;

  try {
    // Generate short code (e.g., using hashing algorithm)
    const shortCode = generateShortCode(longUrl);

    // Save URL to database
    const url = new URL({ longUrl, shortCode });
    await url.save();

    // Return shortened URL to frontend
    res.json({ shortUrl: `${req.protocol}://${req.get('host')}/${shortCode}` });
  } catch (err) {
    console.error('Error shortening URL:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/:shortCode', async (req, res) => {
  const { shortCode } = req.params;

  try {
    // Find long URL in database
    const url = await URL.findOne({ shortCode });

    if (url) {
      // Redirect user to original long URL
      res.redirect(url.longUrl);
    } else {
      res.status(404).send('URL not found');
    }
  } catch (err) {
    console.error('Error redirecting URL:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// Example function to generate short code (replace with your actual implementation)
function generateShortCode(longUrl) {
  return Math.random().toString(36).substring(2, 8);
}
