// Using async/await
async function shortenUrl() {
    const longUrl = document.getElementById('longUrl').value;
  
    try {
      const response = await fetch('/shorten', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ longUrl })
      });
  
      if (!response.ok) {
        throw new Error('Failed to shorten URL');
      }
  
      const data = await response.json();
      document.getElementById('shortUrl').value = data.shortUrl;
    } catch (error) {
      console.error('Error shortening URL:', err);
      // Handle error (e.g., display error message to user)
    }
  }
  